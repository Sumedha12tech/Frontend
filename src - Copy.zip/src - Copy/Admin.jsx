import React from 'react';

function Admin() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Navbar */}
      <nav className="flex items-center justify-between px-6 py-4 bg-gray-800 w-full">
        <div className="flex items-center gap-2">
          <img src="/logo.png" alt="Logo" className="h-8 w-8" />
          <h1 className="text-lg font-bold">Admin Dashboard</h1>
        </div>
        <div className="flex-grow mx-6">
          <input
            type="text"
            placeholder="Search"
            className="w-full px-4 py-2 rounded border bg-slate-100 text-gray-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>
        <div>
          <img
            src="/avatar.png"
            alt="Avatar"
            className="h-10 w-10 rounded-full border-2 border-purple-500"
          />
        </div>
      </nav>

      {/* Main Dashboard */}
      <div className="px-6 py-4 w-full">
        {/* Welcome Section */}
        <div className="mb-6 text-center">
          <h2 className="text-2xl font-semibold">Welcome Back, React Patterns</h2>
          <p className="text-gray-400">Seamless Video Management, Elevated Results.</p>
        </div>

        {/* Metrics Section */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="p-4 bg-gray-800 rounded-lg text-center">
            <h3 className="text-lg font-medium">Total Views</h3>
            <p className="text-3xl font-bold">221,234</p>
          </div>
          <div className="p-4 bg-gray-800 rounded-lg text-center">
            <h3 className="text-lg font-medium">Total Subscribers</h3>
            <p className="text-3xl font-bold">4,053</p>
          </div>
          <div className="p-4 bg-gray-800 rounded-lg text-center">
            <h3 className="text-lg font-medium">Total Likes</h3>
            <p className="text-3xl font-bold">63,021</p>
          </div>
        </div>

        {/* Video Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-800">
                <th className="p-4 border-b border-gray-700">Status</th>
                <th className="p-4 border-b border-gray-700">Uploaded</th>
                <th className="p-4 border-b border-gray-700">Rating</th>
                <th className="p-4 border-b border-gray-700">Date Uploaded</th>
              </tr>
            </thead>
            <tbody>
              {[
                {
                  status: 'Published',
                  video: 'JavaScript Fundamentals: Variables and Data Types',
                  rating: '921 likes | 49 dislikes',
                  date: '9/22/2023',
                },
                {
                  status: 'Unpublished',
                  video: 'React Hooks Explained: useState and useEffect',
                  rating: '2520 likes | 279 dislikes',
                  date: '9/21/2023',
                },
                // Add more entries here
              ].map((row, index) => (
                <tr key={index} className="hover:bg-gray-700">
                  <td className="p-4 border-b border-gray-700">
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        row.status === 'Published'
                          ? 'bg-green-500 text-white'
                          : 'bg-red-500 text-white'
                      }`}
                    >
                      {row.status}
                    </span>
                  </td>
                  <td className="p-4 border-b border-gray-700">{row.video}</td>
                  <td className="p-4 border-b border-gray-700">{row.rating}</td>
                  <td className="p-4 border-b border-gray-700">{row.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Admin;
