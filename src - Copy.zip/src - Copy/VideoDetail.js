const VideoDetails = () => {
    return <h1>Video Detail Page</h1>;
  };
  
  export default VideoDetails;