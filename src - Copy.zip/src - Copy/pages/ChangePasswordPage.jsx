import React from "react";
import ChangePassword from "../Password";
import SideBar from "../SideBar";
import NavBar from "../NavBar";



const ChangePasswordPage = () => {
  return (
    <div>
      <NavBar/>
      <div>
        <ChangePassword/>
        <SideBar/>
      </div>
    </div>
  )
};
export default ChangePasswordPage;