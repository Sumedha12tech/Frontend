import React from "react";
import UploadVideoCard from "../UploadVideo";
import Sidebar from "../SideBar";
import NavBar from "../NavBar";

const VideoUploadPage = () => {
    return (
      <div>
        <NavBar/>
        <div>
          <UploadVideoCard/>
          <Sidebar/>
        </div>
      </div>
    )
  }
  export default VideoUploadPage;