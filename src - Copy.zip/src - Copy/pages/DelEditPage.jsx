import React from "react";
import DeleteVideo from "../DelandEditVideo";
//import NavBar from "../NavBar";



const DeleteVideoPage = () => {
  return (
    
      <div>
        <DeleteVideo/>
        
      </div>
    
  )
};
export default DeleteVideoPage;