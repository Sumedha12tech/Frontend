import React from "react";
import VideosCart from "../VideosCart";
import Sidebar from "../SideBar";
import NavBar from "../NavBar";



const Home = () => {
  return (
    <div>
      <NavBar/>
      <div>
        <VideosCart/>
        <Sidebar/>
      </div>
    </div>
  )
}





export default Home;