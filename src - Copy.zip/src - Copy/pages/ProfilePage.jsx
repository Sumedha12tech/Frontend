import React from "react";
import UserProfile from "../UserProfile";
import Sidebar from "../SideBar";
import NavBar from "../NavBar";

const ProfilePage = () => {
  return (
    <div>
      <NavBar/>
      <div>
      
        <UserProfile/>
        <Sidebar/>
      </div>
    </div>
  )
}

export default ProfilePage;
