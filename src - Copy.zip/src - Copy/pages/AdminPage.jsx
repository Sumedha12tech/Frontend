import React from "react";
import Admin from "../Admin";
import NavBar from "../NavBar";



const AdminPage = () => {
  return (
    <div>
      <NavBar/>
      <div>
        <Admin/>
        
      </div>
    </div>
  )
}
export default AdminPage;