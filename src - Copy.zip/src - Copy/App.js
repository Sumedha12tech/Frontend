import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import ProfilePage from "./pages/ProfilePage";
import ChangePasswordPage from "./pages/ChangePasswordPage";
import DeleteVideoPage from "./pages/DelEditPage";
import VideoUploadPage from "./pages/VideoUploadPage";
import AdminPage from "./pages/AdminPage";

const App = () => {
  return (
    <div>
    <Router>
      <Routes>
      <Route path="/" element={<Home/>} />
      <Route path="/" element={<ProfilePage/>} />
      <Route path="/" element={<VideoUploadPage/>} />
      <Route path="/" element={<DeleteVideoPage/>} />
      <Route path="/" element={<ChangePasswordPage/>} />
      <Route path="/" element={<AdminPage/>} />
      </Routes>
    </Router>
    </div>
  );
};
export default App;