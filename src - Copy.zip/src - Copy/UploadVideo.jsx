import React, { useState } from "react";

const UploadVideoCard = () => {
  const [isUploading, setIsUploading] = useState(false); // Track upload state
  const [uploadProgress, setUploadProgress] = useState(0); // Track progress
  const [uploadedFiles, setUploadedFiles] = useState([]); // Track uploaded files

  // Simulate upload process
  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setUploadedFiles((prevFiles) => [...prevFiles, ...files]);
          return 100;
        }
        return prev + 10; // Increment progress
      });
    }, 500); // Update every 0.5 seconds
  };

  const handleCancelUpload = () => {
    setIsUploading(false);
    setUploadProgress(0);
  };

  const handleFinishUpload = () => {
    setIsUploading(false);
    alert("Upload finished!");
  };

  // Handle file deletion
  const handleDeleteFile = (fileName) => {
    setUploadedFiles((prevFiles) => prevFiles.filter((file) => file.name !== fileName));
  };

  return (
    <div className="bg-gray-800 text-white w-50  mx-auto mt-20 p-5 pl-60 rounded-lg shadow-lg max-h-[90vh] overflow-y-auto relative">
      {/* Header */}
      <div className="text-center mb-4">
        <h2 className="text-lg font-semibold text-gray-300">Upload Videos</h2>
      </div>

      {/* Upload Box */}
      <div className="border-2 border-dashed border-gray-500 p-5 pl-16 text-center rounded-lg mb-4">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.5"
          stroke="currentColor"
          className="w-12 h-12 mx-auto mb-3 text-gray-400"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M12 16.5v-12m0 0l3.75 3.75M12 4.5L8.25 8.25M21 16.5a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 16.5v-9a2.25 2.25 0 012.25-2.25h4.908c.107-.19.231-.369.369-.537l1.902-2.278A1.125 1.125 0 0113.125 3h3.75A1.125 1.125 0 0118 4.125v2.25a1.125 1.125 0 01-.331.794l-1.902 2.278c-.138.168-.262.347-.369.537H18.75A2.25 2.25 0 0121 7.5v9z"
          />
        </svg>
        <p className="text-gray-400">Drag and drop video files to upload</p>
        <label
          htmlFor="video-upload"
          className="mt-2 inline-block bg-purple-600 text-white px-5 py-2 rounded-md cursor-pointer hover:bg-purple-500"
        >
          Select Files
          <input
            type="file"
            id="video-upload"
            className="hidden"
            multiple
            accept="video/*"
            onChange={handleFileUpload}
          />
        </label>
      </div>

      {/* Thumbnail */}
      <div className="mb-4">
        <label htmlFor="thumbnail" className="block text-sm font-medium text-gray-400 mb-1">
          Thumbnail*
        </label>
        <input
          type="file"
          id="thumbnail"
          className="block w-full text-sm text-gray-400 bg-gray-700 border border-gray-600 rounded-lg p-2 cursor-pointer"
          accept="image/*"
        />
      </div>

      {/* Title */}
      <div className="mb-4">
        <label htmlFor="title" className="block text-sm font-medium text-gray-400 mb-1">
          Title*
        </label>
        <input
          type="text"
          id="title"
          className="block w-full p-2 text-sm bg-gray-700 text-gray-200 border border-gray-600 rounded-lg"
          placeholder="Enter video title"
        />
      </div>

      {/* Description */}
      <div className="mb-4">
        <label htmlFor="description" className="block text-sm font-medium text-gray-400 mb-1">
          Description*
        </label>
        <textarea
          id="description"
          className="block w-full p-2 text-sm bg-gray-700 text-gray-200 border border-gray-600 rounded-lg"
          placeholder="Enter video description"
          rows="4"
        ></textarea>
      </div>

      {/* Uploaded Files */}
      <div className="mb-4">
        <h3 className="text-gray-300 text-sm font-medium mb-2">Uploaded Files:</h3>
        {uploadedFiles.length > 0 ? (
          <ul className="bg-gray-700 rounded-lg p-3 max-h-32 overflow-y-auto">
            {uploadedFiles.map((file, index) => (
              <li key={index} className="flex justify-between items-center text-sm text-gray-200">
                <span>{file.name}</span>
                <button
                  onClick={() => handleDeleteFile(file.name)}
                  className="text-red-600 hover:text-red-400"
                >
                  &#10005; {/* Cross icon */}
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500 text-sm">No files uploaded yet.</p>
        )}
      </div>

      {/* Save Button */}
      <button className="w-full bg-purple-600 hover:bg-purple-500 text-white font-medium py-2 rounded-lg">
        Save
      </button>

      {/* Upload Buffer Popup */}
      {isUploading && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-5 rounded-lg text-center">
            <p className="text-white mb-4">Uploading... {uploadProgress}%</p>
            <div className="w-full bg-gray-700 rounded-full h-2 mb-4">
              <div
                className="bg-purple-600 h-2 rounded-full"
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
            <div className="flex justify-around">
              <button
                onClick={handleCancelUpload}
                className="bg-red-600 px-4 py-2 rounded-lg text-white hover:bg-red-500"
              >
                Cancel
              </button>
              {uploadProgress >= 100 && (
                <button
                  onClick={handleFinishUpload}
                  className="bg-green-600 px-4 py-2 rounded-lg text-white hover:bg-green-500"
                >
                  Finish
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UploadVideoCard;
