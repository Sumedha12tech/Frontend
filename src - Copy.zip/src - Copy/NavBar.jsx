import React, { useState } from "react";
import { FiSearch } from "react-icons/fi"; // Import search icon

const NavBar = () => {
  const [searchTerm, setSearchTerm] = useState("");

  return (
    <div className="w-full bg-gray-800 border-b border-gray-700 flex items-center justify-between p-4 fixed top-0 z-10">
      {/* Logo */}
      <div className="flex items-center space-x-2">
        <div className="bg-purple-500 p-2 rounded-full">
          <span className="text-lg font-bold">Play</span>
        </div>
      </div>

      {/* Search Bar */}
      <div className="flex items-center justify-center flex-1">
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search..."
            className="w-80 px-4 py-2 text-white bg-slate-950 rounded-lg border border-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <FiSearch
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
            size={20}
          />
        </div>
      </div>

      {/* Buttons */}
      <div className="flex items-center space-x-4">
        <button className="px-4 py-2 border border-gray-500 rounded text-white bg-purple-500 hover:bg-gray-700">
          Log in
        </button>
        <button className="px-4 py-2 border border-gray-500 rounded text-white bg-purple-500 hover:bg-purple-600">
          Sign up
        </button>
      </div>
    </div>
  );
};

export default NavBar;
