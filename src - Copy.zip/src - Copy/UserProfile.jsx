import React, { useState } from "react";

const UserProfile = () => {
  const [activeTab, setActiveTab] = useState("videos"); // videos, tweets, subscribed

  // Manual content for Tweets
  const manualTweets = [
    {
      content: "Learning React is fun!",
      author: "John Doe",
      avatar: "https://via.placeholder.com/50",
    },
    {
      content: "Check out this awesome project!",
      author: "Jane Smith",
      avatar: "https://via.placeholder.com/50",
    },
    {
      content: "React Patterns are amazing!",
      author: "Alice Brown",
      avatar: "https://via.placeholder.com/50",
    },
  ];

  // Manual content for Subscribers
  const manualSubscribers = [
    {
      name: "Alice",
      avatar: "https://via.placeholder.com/50",
    },
    {
      name: "Bob",
      avatar: "https://via.placeholder.com/50",
    },
    {
      name: "Charlie",
      avatar: "https://via.placeholder.com/50",
    },
    {
      name: "Diana",
      avatar: "https://via.placeholder.com/50",
    },
  ];

  return (
    <div className=" min-h-screen py-20 px-15 bg-gray-900 text-white">
      {/* Background Image */}
      <div className=" relative h-48 w-full bg-gray-700">
        <img
          src="https://via.placeholder.com/1500x300"
          alt="Background"
          className="h-full w-full object-cover"
        />
      </div>

      {/* Profile Section */}
      <div className="relative -mt-16 mx-auto max-w-7xl px-10 sm:px-6 lg:px-8">
        <div className="bg-gray-800 rounded-lg shadow-lg px-6 py-4">
          <div className="flex items-center justify-between space-x-6">
            {/* Left Section */}
            <div className="flex items-center space-x-6">
              {/* Avatar */}
              <div className="w-24 h-24 rounded-full border-4 border-gray-900 overflow-hidden">
                <img
                  src="https://via.placeholder.com/150"
                  alt="Avatar"
                  className="h-full w-full object-cover"
                />
              </div>
              <div>
                {/* Profile Info */}
                <h1 className="text-2xl font-semibold">React Patterns</h1>
                <p className="text-gray-400">@reactpatterns</p>
                <p className="text-sm text-gray-400">600k Subscribers · 220 Subscribed</p>
              </div>
            </div>

            {/* Subscribe Button */}
            <button className="bg-purple-600 hover:bg-purple-700 px-2 py-2 rounded text-white">
              Subscribe
            </button>
          </div>

          {/* Navigation Buttons */}
          <div className="mt-6 flex justify-between">
            <button
              className={`${
                activeTab === "videos" ? "bg-purple-600" : "bg-gray-700"
              } hover:bg-purple-700 px-4 py-2 rounded text-white`}
              onClick={() => setActiveTab("videos")}
            >
              Videos
            </button>
            <button
              className={`${
                activeTab === "tweets" ? "bg-purple-600" : "bg-gray-700"
              } hover:bg-purple-700 px-4 py-2 rounded text-white`}
              onClick={() => setActiveTab("tweets")}
            >
              Tweets
            </button>
            <button
              className={`${
                activeTab === "subscribed" ? "bg-purple-600" : "bg-gray-700"
              } hover:bg-purple-700 px-4 py-2 rounded text-white`}
              onClick={() => setActiveTab("subscribed")}
            >
              Subscribed
            </button>
          </div>
        </div>
      </div>

      {/* Active Tab Content */}
      <div className="mt-4 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {activeTab === "videos" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
            {/* Video Card */}
            {Array.from({ length: 4 }).map((_, index) => (
              <div
                key={index}
                className="bg-gray-800 rounded-lg shadow-lg overflow-hidden"
              >
                <img
                  src="https://via.placeholder.com/400x200"
                  alt={`Video Thumbnail ${index}`}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="text-lg font-semibold">
                    Video Title {index + 1}
                  </h3>
                  <p className="text-sm text-gray-400">10.3k Views · 44 minutes ago</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === "tweets" && (
          <div>
            <h2 className="text-xl font-semibold">Tweets</h2>
            {manualTweets.map((tweet, index) => (
              <div
                key={index}
                className="bg-gray-800 rounded-lg p-4 mt-4 shadow-lg flex items-center space-x-4"
              >
                <div className="w-12 h-12 rounded-full bg-gray-900 border-2 border-purple-500 flex-shrink-0">
                  <img
                    src={tweet.avatar}
                    alt={`Avatar of ${tweet.author}`}
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
                <div>
                  <p className="text-sm text-gray-400">{tweet.content}</p>
                  <p className="text-xs text-gray-500">By: {tweet.author}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === "subscribed" && (
          <div>
            <h2 className="text-xl font-semibold">Subscribers</h2>
            {manualSubscribers.map((subscriber, index) => (
              <div
                key={index}
                className="bg-gray-800 rounded-lg p-4 mt-4 shadow-lg flex items-center space-x-4"
              >
                <div className="w-12 h-12 rounded-full bg-gray-900 border-2 border-purple-500 flex-shrink-0">
                  <img
                    src={subscriber.avatar}
                    alt={`Avatar of ${subscriber.name}`}
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
                <p className="text-sm text-gray-400">{subscriber.name}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default UserProfile;
