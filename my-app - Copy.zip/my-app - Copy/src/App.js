import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
//import NavBar from "./NavBar";
//import SideBar from "./SideBar";
//import VideosCart from "./VideosCart";
//import ProfilePage from "./pages/ProfilePage";
import Home from "./pages/Home";

const App = () => {
  return (
    <div>
    <Router>
      <Routes>
        <Route path="/" element={<Home/>} />
      </Routes>
    </Router>
    </div>
  );
};
export default App;