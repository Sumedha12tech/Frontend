const ChannelVideoList = () => {
    return <h1>Channel Video List Page</h1>;
  };
  
  export default ChannelVideoList;