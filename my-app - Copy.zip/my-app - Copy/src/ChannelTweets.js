const ChannelTweets = () => {
    return <h1>Welcome to the Channel Tweets Page</h1>;
  };
  
  export default ChannelTweets;