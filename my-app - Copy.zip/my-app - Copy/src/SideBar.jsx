import React from "react";

const SideBar = () => {
  return (
    <div className="w-1/5 min-h-screen bg-gray-900 border-r border-gray-700 p-4 fixed top-16 flex flex-col">
      {/* Menu Items */}
      <ul className="space-y-4 flex-1">
        <li className="p-2 border border-slate-100 text-slate-100 rounded flex items-center hover:bg-gray-800 cursor-pointer">
          <span>Home</span>
        </li>
        <li className="p-2 border border-slate-100 text-slate-100 rounded flex items-center hover:bg-gray-800 cursor-pointer">
          <span>Liked Videos</span>
        </li>
        <li className="p-2 border border-slate-100 text-slate-100 rounded flex items-center hover:bg-gray-800 cursor-pointer">
          <span>History</span>
        </li>
        <li className="p-2 border border-slate-100 text-slate-100 rounded flex items-center hover:bg-gray-800 cursor-pointer">
          <span>My Content</span>
        </li>
        <li className="p-2 border border-slate-100 text-slate-100 rounded flex items-center hover:bg-gray-800 cursor-pointer">
          <span>Collections</span>
        </li>
        <li className="p-2 border border-slate-100 text-slate-100 rounded flex items-center hover:bg-gray-800 cursor-pointer">
          <span>Subscribers</span>
        </li>
        <li className="p-2 border border-slate-100 text-slate-100 rounded flex items-center hover:bg-gray-800 cursor-pointer mt-16">
          <span>Settings</span>
        </li>
      </ul>
    </div>
  );
};

export default SideBar;
