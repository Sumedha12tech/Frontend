import React, { useState } from "react";
//import "./VideosCart.css";

const videos = [
  {
    title: "Creating Custom Hooks in React",
    views: "9.3k Views",
    time: "9 hours ago",
    channel: "Hook Master",
    duration: "16:37",
    videoFile: "/videos/video.mp4", // Correct relative path
    avatar: "https://via.placeholder.com/40", // Avatar image URL
  },
  {
    title: "Building Scalable Web Applications with Django",
    views: "18.9M Views",
    time: "12 hours ago",
    channel: "Django Master",
    duration: "32:18",
    image: "https://via.placeholder.com/300x150", // Replace with your image URL
    avatar: "https://via.placeholder.com/40", // Avatar image URL
  },
  {
    title: "Creating Interactive UIs with React and D3",
    views: "20.1k Views",
    time: "14 hours ago",
    channel: "ReactD3",
    duration: "29:30",
    image: "https://via.placeholder.com/300x150", // Replace with your image URL
    avatar: "https://via.placeholder.com/40", // Avatar image URL
  },
];

const VideosCart = () => {
  const [currentView, setCurrentView] = useState("landing"); // "landing" or "playback"
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState("");
  const [likes, setLikes] = useState(0);
  const [dislikes, setDislikes] = useState(0);

  const handleVideoClick = (video) => {
    setSelectedVideo(video); // Set the clicked video as selected
    setCurrentView("playback"); // Switch to the playback layout
  };

  const handleBackClick = () => {
    setCurrentView("landing"); // Return to landing layout
    setSelectedVideo(null); // Clear selected video
    setComments([]); // Reset comments
    setLikes(0); // Reset likes
    setDislikes(0); // Reset dislikes
  };

  const handleAddComment = () => {
    if (newComment.trim()) {
      setComments([...comments, newComment]);
      setNewComment(""); // Clear input
    }
  };

  return (
    <div className="flex-1 p-6 bg-slate-950">
      {currentView === "landing" ? (
        // Landing Page Layout

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
          {videos.map((video, index) => (
            <div
              key={index}
              className="space-y-4 cursor-pointer"
              onClick={() => handleVideoClick(video)} // Handle click
            >
              <div className="relative">
                {video.videoFile ? (
                  <video
                    controls
                    className="w-full h-40 object-cover rounded-lg bg-slate-100"
                  >
                    <source src={video.videoFile} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                ) : (
                  <img
                    src={video.image}
                    alt={video.title}
                    className="w-full h-40 object-cover rounded-lg bg-slate-100"
                  />
                )}
                <span className="absolute bottom-2 right-2 bg-black text-white text-xs px-2 py-1 rounded">
                  {video.duration}
                </span>
              </div>
              <div className="flex items-center text-gray-200">
                <div className="w-8 h-8 rounded-full overflow-hidden mr-3">
                  <img
                    src={video.avatar}
                    alt={video.channel}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">{video.title}</h3>
                  <p className="text-sm text-gray-400">
                    {video.views} • {video.time}
                  </p>
                  <p className="text-sm text-gray-400">{video.channel}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        // Playback Layout
        <div className="flex flex-col md:flex-row gap-6">
          {/* Left: Video Player */}
          <div className="flex-1">
            <button
              className="mb-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
              onClick={handleBackClick} // Back button
            >
              ← Back
            </button>
            <video
              controls
              className="w-full h-[400px] object-cover rounded-lg bg-slate-100"
            >
              <source src={selectedVideo.videoFile} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
            <div className="mt-4 text-gray-200">
              <div className="flex items-center">
                <img
                  src={selectedVideo.avatar}
                  alt={selectedVideo.channel}
                  className="w-10 h-10 rounded-full mr-3"
                />
                <div>
                  <h3 className="text-xl font-semibold">{selectedVideo.title}</h3>
                  <p className="text-sm text-gray-400">{selectedVideo.channel}</p>
                </div>
              </div>
              <div className="mt-2 flex items-center space-x-4">
                <button
                  className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
                  onClick={() => setLikes(likes + 1)}
                >
                  👍 {likes}
                </button>
                <button
                  className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                  onClick={() => setDislikes(dislikes + 1)}
                >
                  👎 {dislikes}
                </button>
              </div>
            </div>
            <div className="mt-6">
              <h4 className="text-lg font-semibold text-gray-200 mb-2">
                Comments
              </h4>
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  placeholder="Add a comment..."
                  className="flex-1 px-4 py-2 rounded bg-gray-800 text-white"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                />
                <button
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
                  onClick={handleAddComment}
                >
                  Post
                </button>
              </div>
              <div className="mt-4 space-y-3">
                {comments.map((comment, index) => (
                  <div
                    key={index}
                    className="p-2 bg-gray-800 rounded text-white"
                  >
                    {comment}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Video List */}
          <div className="w-full md:w-1/3 max-h-[calc(100vh-4rem)] overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-slate-100">
            {videos.map((video, index) => (
              <div
                key={index}
                className={`flex items-center space-x-4 p-4 bg-slate-800 rounded-lg mb-4 cursor-pointer hover:bg-slate-700 transition ${
                  selectedVideo.title === video.title
                    ? "ring-2 ring-blue-500"
                    : ""
                }`}
                onClick={() => setSelectedVideo(video)} // Change video on click
              >
                <img
                  src={video.image || "https://via.placeholder.com/300x150"}
                  alt={video.title}
                  className="w-20 h-20 object-cover rounded-lg"
                />
                <div>
                  <h3 className="text-lg font-semibold text-gray-200">
                    {video.title}
                  </h3>
                  <p className="text-sm text-gray-400">
                    {video.views} • {video.time}
                  </p>
                  <p className="text-sm text-gray-400">{video.channel}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default VideosCart;

